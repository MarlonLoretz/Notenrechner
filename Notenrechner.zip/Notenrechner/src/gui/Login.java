package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import Data.Person;
import gui.Register;


public class Login extends JFrame{
	
	
	
	private JButton exit = new JButton("Zur�ck");
	private JButton refresh = new JButton("Refresh");
	private JButton help = new JButton("Hilfe");
	private JButton submit = new JButton("Einloggen");
	
	private JLabel login = new JLabel("LOGIN");
	private JLabel name = new JLabel("Benutzername");
	private JLabel password = new JLabel("Passwort");
	
	private JTextArea nameArea = new JTextArea(100, 50);
	private JTextArea passwordArea = new JTextArea(100, 50);
	
	JPanel buttonPanel = new JPanel();
	JPanel dataPanel = new JPanel();
	JPanel titlePanel = new JPanel();

	
	public Login() {
		init();
	}
	
	public void init(){
		
		titlePanel.add(login);
		titlePanel.setSize(300, 100);
		
		dataPanel.setLayout(new GridLayout(2,2));
		dataPanel.setSize(300, 100);
		dataPanel.add(name);
		dataPanel.add(nameArea);
		nameArea.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		dataPanel.add(password);
		dataPanel.add(passwordArea);
		passwordArea.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		
		buttonPanel.setLayout(new GridLayout(1,4));
		buttonPanel.setSize(300, 100);
		buttonPanel.add(exit);
		buttonPanel.add(refresh);
		buttonPanel.add(help);
		buttonPanel.add(submit);
	
		
		getContentPane().add(titlePanel, BorderLayout.NORTH);
		getContentPane().add(dataPanel, BorderLayout.CENTER);
		getContentPane().add(buttonPanel, BorderLayout.SOUTH);
		
		
		setSize(400, 130);
		setTitle("Login");
		setVisible(true);
		setResizable(false);
		
		
		help.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					Help help = new Help();			
			}
		});
		exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Start s = new Start();
				dispose();
			}
		});
		refresh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				nameArea.setText("");
				passwordArea.setText("");
			}
		});
		submit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				check();
			}
		});
				
	}
	
	public void check() {
		Person person = new Person(Register.NAME, Register.PASSWORD);
		if(! nameArea.getText().equals(person.getName())) {
			nameArea.setBorder(BorderFactory.createLineBorder(Color.RED));
		}else if(! passwordArea.getText().equals(person.getPassword())){
			passwordArea.setBorder(BorderFactory.createLineBorder(Color.RED));
		}else {
			Menu menu = new Menu();
			dispose();
		}
		
	}
}
