package gui;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class Menu extends JFrame {
	
	private JLabel title= new JLabel("W�hlen Sie ihre F�cher");
	
	private static JRadioButton german = new JRadioButton("Deutsch");
	private static JRadioButton french = new JRadioButton("Franz�sisch");
	private static JRadioButton english = new JRadioButton("Englisch");
	private static JRadioButton math = new JRadioButton("Mathematik");
	private static JRadioButton economy = new JRadioButton("Wirtschaft & Recht");
	private static JRadioButton finances = new JRadioButton("Finanz- und Rechnungswesen");
	
	private JButton submit = new JButton("Submit");
	private JButton exit = new JButton("Exit");
	private JButton blank = new JButton("Leeren");

	
	private JPanel radio = new JPanel();
	private JPanel buttonPanel = new JPanel();
	
	private static boolean status;
	
	
	public Menu() {
		init();
	}
	
	public void init() {
		
		title.setFont(new Font("Arial", Font.BOLD, 12));
		
		radio.setLayout(new GridLayout(6,1));
		radio.add(german);
		radio.add(french);
		radio.add(english);
		radio.add(math);
		radio.add(economy);
		radio.add(finances);
		
		german.setSelected(true);
		french.setSelected(true);
		english.setSelected(true);
		math.setSelected(true);
		economy.setSelected(true);
		finances.setSelected(true);
		
		buttonPanel.setLayout(new GridLayout(1,3));
		buttonPanel.add(exit);
		buttonPanel.add(blank);
		buttonPanel.add(submit);
	
		
		getContentPane().add(title, BorderLayout.NORTH);
		getContentPane().add(radio, BorderLayout.CENTER);
		getContentPane().add(buttonPanel, BorderLayout.SOUTH);
		
		
		setSize(350, 150);
		setTitle("Notenrechner");
		setVisible(true);
		setResizable(false);
		
		
		exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Start s = new Start();
				dispose();
			}
		});
		blank.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				german.setSelected(false);
				french.setSelected(false);
				english.setSelected(false);
				math.setSelected(false);
				economy.setSelected(false);
				finances.setSelected(false);
			}
		});
		submit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Rechner rechner = new Rechner();
				dispose();
			}
		});

		
	}
	
	public static  boolean mathState() {
		if(math.isSelected()) {
			status = true;
		}else {
			status = false;
		}
	return status;
	}
	
	public static boolean germanState() {
		if(german.isSelected()) {
			status = true;
		}else {
			status = false;
		}
	return status;
	}
	
	public static boolean frenchState() {
		if(french.isSelected()) {
			status = true;
		}else {
			status = false;
		}
	return status;
	}
	
	public static boolean englishState() {
		if(english.isSelected()) {
			status = true;
		}else {
			status = false;
		}
	return status;
	}
	
	public static boolean economyState() {
		if(economy.isSelected()) {
			status = true;
		}else {
			status = false;
		}
	return status;
	}
	
	public static boolean financesState() {
		if(finances.isSelected()) {
			status = true;
		}else {
			status = false;
		}
	return status;
	}
	
	
}
	
