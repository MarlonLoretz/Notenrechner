package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import Data.Person;
import gui.Start;

public class Register extends JFrame {
	
	static String NAME;
	static String PASSWORD;
	
	
	private JLabel welcome = new JLabel("Erstellen Sie einen neue Account");
	private JLabel name = new JLabel("Name: ");
	private JTextField nameT = new JTextField();
	private JLabel password = new JLabel("Passwort: ");
	private JTextField passwordT = new JTextField();
	private JLabel password2 = new JLabel("Passwort erneut eingeben: ");
	private JTextField password2T = new JTextField();
	
	private JButton cancel = new JButton("Abbruch");
	private JButton submit = new JButton("Best�tigen");
	
	
	public Register() {	
		init();	
	}
	
	public void init() {
		
		JPanel data = new JPanel();
		data.setLayout(new GridLayout(6, 1));
		data.add(name);
		data.add(nameT);
		data.add(password);
		data.add(passwordT);
		data.add(password2);
		data.add(password2T);
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new GridLayout(1,2));
		buttonPanel.add(cancel);
		buttonPanel.add(submit);
		
		
		getContentPane().add(welcome, BorderLayout.NORTH);
		getContentPane().add(data, BorderLayout.CENTER);
		getContentPane().add(buttonPanel, BorderLayout.SOUTH);
		
		
		setSize(250, 180);
		setTitle("Registrieren");
		setVisible(true);
		setResizable(false);
		
		cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Start s = new Start();
				dispose();
			}
		});
		submit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				check();			
			}
		});		
	}
	
	
	public void check() {
		if(nameT.getText().isEmpty()) {
			nameT.setBorder(BorderFactory.createLineBorder(Color.RED));
		}else if(passwordT.getText().isEmpty()) {
			passwordT.setBorder(BorderFactory.createLineBorder(Color.RED));
		}else if(! passwordT.getText().equals(password2T.getText())) {
			passwordT.setBorder(BorderFactory.createLineBorder(Color.RED));
			password2T.setBorder(BorderFactory.createLineBorder(Color.RED));
		}else {
			
			PASSWORD = passwordT.getText();
			NAME = nameT.getText();
			Login login = new Login();
			dispose();
		}
	}
}
