package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class Start extends JFrame{
	
	private JLabel welcome = new JLabel("WILKOMMEN BEIM NOTENRECHNER");
	   
	private String beschreibung = 	"Author       : Marlon Loretz \r\n" +
			 						"Version     : 1.0 \r\n" +
			 						"\r\n" +
									"Beschreibung: \r\n" + 
									" Dieser kleine Notenrechner dient dazu \r\n" +
									" seine Noten in den 6 Hauptf�chern festzu- \r\n" +
									" halten und seinen Durchschnitt immer im \r\n" +
									" Blick zu halten.";
	
	private JTextArea desc = new JTextArea(beschreibung);
	
	private JButton exit = new JButton("Schliessen");
	private JButton login = new JButton("Einloggen");
	private JButton register = new JButton("Registrieren");
	
	public Start() {
		init();
	}
	
	public void init() {
		
		welcome.setFont(new Font( "Arial", Font.BOLD, 16));
		
		JPanel welcomePanel = new JPanel();
		welcomePanel.setLayout(new GridLayout(1,1));
		welcomePanel.setBackground(Color.lightGray);
		welcomePanel.add(welcome);
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new GridLayout(1,3));
		buttonPanel.add(exit);
		buttonPanel.add(register);
		buttonPanel.add(login);
		
		JPanel descPanel = new JPanel();
		descPanel.setLayout(new GridLayout(1,1));
		descPanel.add(desc);
		desc.setEditable(false);
		desc.setBackground(Color.lightGray);

		
		
		getContentPane().add(welcomePanel, BorderLayout.NORTH);
		getContentPane().add(descPanel, BorderLayout.CENTER);
		getContentPane().add(buttonPanel, BorderLayout.SOUTH);
		
		
		setSize(320, 200);
		setTitle("Notenrechner");
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		register.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Register r = new Register();
				dispose();
				
			}
		});
		login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login l = new Login();
				dispose();
			}

		});
	}

}
