package gui;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class Help extends JFrame{

	String help = 	"Hilfe: \r\n" + 
					" Um sich einzuloggen m�ssen Sie zuerst  \r\n" +
					" einen Account einrichten, indem Sie auf \r\n" +
					" Registrieren dr�cken.";
	
	private JTextArea helpArea = new JTextArea(help);
	
	public Help() {
		
		init();
	}
	
	public void init() {
		
		
		JPanel panel = new JPanel();		
		panel.setLayout(new BorderLayout(200, 50));
		panel.add(helpArea, BorderLayout.CENTER);
		
		
		
		getContentPane().add(panel, BorderLayout.CENTER);
		
		
		setSize(250, 100);
		setTitle("Hilfe");
		setVisible(true);
		setResizable(false);
	}
}
