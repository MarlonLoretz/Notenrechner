package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class Rechner extends JFrame{
	
	private JLabel description = new JLabel("Fach");
	private JLabel sem1 = new JLabel("1. Semester");
	private JLabel sem2 = new JLabel("2. Semester");
	private JLabel sem3 = new JLabel("3. Semester");
	private JLabel sem4 = new JLabel("4. Semester");
	private JLabel sem5 = new JLabel("5. Semester");
	private JLabel sem6 = new JLabel("6. Semester");
	private JLabel descAvg = new JLabel("Durchschnitt:");
	private JLabel totalJLabel = new JLabel("Total");
	private JLabel total = new JLabel("Total");
	
	private JLabel math = new JLabel("Mathematik");
	private JTextArea math1 = new JTextArea(50, 50);
	private JTextArea math2 = new JTextArea(50, 50);
	private JTextArea math3 = new JTextArea(50, 50);
	private JTextArea math4 = new JTextArea(50, 50);
	private JTextArea math5 = new JTextArea(50, 50);
	private JTextArea math6 = new JTextArea(50, 50);
	private JLabel mAverage = new JLabel("Durchschnitt:");
	private JLabel mathAverage = new JLabel("");

	private JLabel english = new JLabel("Englisch");
	private JTextArea english1 = new JTextArea(50, 50);
	private JTextArea english2 = new JTextArea(50, 50);
	private JTextArea english3 = new JTextArea(50, 50);
	private JTextArea english4 = new JTextArea(50, 50);
	private JTextArea english5 = new JTextArea(50, 50);
	private JTextArea english6 = new JTextArea(50, 50);
	private JLabel eAverage = new JLabel("Durchschnitt:");
	private JLabel englishAverage = new JLabel("");

	private JLabel german = new JLabel("Deutsch");
	private JTextArea german1 = new JTextArea(50, 50);
	private JTextArea german2 = new JTextArea(50, 50);
	private JTextArea german3 = new JTextArea(50, 50);
	private JTextArea german4 = new JTextArea(50, 50);
	private JTextArea german5 = new JTextArea(50, 50);
	private JTextArea german6 = new JTextArea(50, 50);
	private JLabel gAverage = new JLabel("Durchschnitt:");
	private JLabel germanAverage = new JLabel("");
	
	private JLabel french = new JLabel("Franz�sisch");
	private JTextArea french1 = new JTextArea(50, 50);
	private JTextArea french2 = new JTextArea(50, 50);
	private JTextArea french3 = new JTextArea(50, 50);
	private JTextArea french4 = new JTextArea(50, 50);
	private JTextArea french5 = new JTextArea(50, 50);
	private JTextArea french6 = new JTextArea(50, 50);
	private JLabel fAverage = new JLabel("Durchschnitt:");
	private JLabel frenchAverage = new JLabel("");
	
	private JLabel economy = new JLabel("Wirtschaft");
	private JTextArea economy1 = new JTextArea(50, 50);
	private JTextArea economy2 = new JTextArea(50, 50);
	private JTextArea economy3 = new JTextArea(50, 50);
	private JTextArea economy4 = new JTextArea(50, 50);
	private JTextArea economy5 = new JTextArea(50, 50);
	private JTextArea economy6 = new JTextArea(50, 50);
	private JLabel wrAverage = new JLabel("Durchschnitt:");
	private JLabel economyAverage = new JLabel("");
	
	private JLabel finances = new JLabel("FrW");
	private JTextArea finances1 = new JTextArea(50, 50);
	private JTextArea finances2 = new JTextArea(50, 50);
	private JTextArea finances3 = new JTextArea(50, 50);
	private JTextArea finances4 = new JTextArea(50, 50);
	private JTextArea finances5 = new JTextArea(50, 50);
	private JTextArea finances6 = new JTextArea(50, 50);
	private JLabel frwAverage = new JLabel("Durchschnitt:");
	private JLabel financesAverage = new JLabel("");
	
	private JButton calc = new JButton("Berechnen");
	private JButton reset = new JButton("Reset");
	private JButton exit = new JButton("Save&Exit");
	
	private JLabel totalLabel = new JLabel("Totaler Durchschnitt: ");
	
	
	public Rechner() {
		init();
	}
	
	public void init() {
		
		JPanel descPanel = new JPanel();
		descPanel.setLayout(new GridLayout(1,9));
		descPanel.add(description);
		descPanel.add(sem1);
		sem1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		descPanel.add(sem2);
		sem2.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		descPanel.add(sem3);
		sem3.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		descPanel.add(sem4);
		sem4.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		descPanel.add(sem5);
		sem5.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		descPanel.add(sem6);
		sem6.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		descPanel.add(descAvg);
		descAvg.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		descPanel.add(totalJLabel);
		totalJLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK));

		
		JPanel mathPanel = new JPanel();
		mathPanel.setLayout(new GridLayout(1,9));
		mathPanel.add(math);
		mathPanel.add(math1);
		math1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		mathPanel.add(math2);
		math2.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		mathPanel.add(math3);
		math3.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		mathPanel.add(math4);
		math4.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		mathPanel.add(math5);
		math5.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		mathPanel.add(math6);
		math6.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		mathPanel.add(mAverage);
		mAverage.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		mathPanel.add(mathAverage);
		mathAverage.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		math1.setText("1.0");
		math2.setText("1.0");
		math3.setText("1.0");
		math4.setText("1.0");
		math5.setText("1.0");
		math6.setText("1.0");
		if(Menu.mathState() == false) {
			mathPanel.setVisible(false);
		}else {}
	
	
		JPanel englishPanel = new JPanel();
		englishPanel.setLayout(new GridLayout(1,9));
		englishPanel.add(english);
		englishPanel.add(english1);
		english1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		englishPanel.add(english2);
		english2.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		englishPanel.add(english3);
		english3.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		englishPanel.add(english4);
		english4.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		englishPanel.add(english5);
		english5.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		englishPanel.add(english6);
		english6.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		englishPanel.add(eAverage);
		eAverage.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		englishPanel.add(englishAverage);
		englishAverage.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		english1.setText("1.0");
		english2.setText("1.0");
		english3.setText("1.0");
		english4.setText("1.0");
		english5.setText("1.0");
		english6.setText("1.0");
		if(Menu.englishState() == false) {
			englishPanel.setVisible(false);
		}else {}
		
		
		JPanel germanPanel = new JPanel();
		germanPanel.setLayout(new GridLayout(1,9));
		germanPanel.add(german);
		germanPanel.add(german1);
		german1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		germanPanel.add(german2);
		german2.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		germanPanel.add(german3);
		german3.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		germanPanel.add(german4);
		german4.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		germanPanel.add(german5);
		german5.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		germanPanel.add(german6);
		german6.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		germanPanel.add(gAverage);
		gAverage.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		germanPanel.add(germanAverage);
		germanAverage.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		german1.setText("1.0");
		german2.setText("1.0");
		german3.setText("1.0");
		german4.setText("1.0");
		german5.setText("1.0");
		german6.setText("1.0");
		if(Menu.germanState() == false) {
			germanPanel.setVisible(false);
		}else {}

		
		JPanel frenchPanel = new JPanel();
		frenchPanel.setLayout(new GridLayout(1,9));
		frenchPanel.add(french);
		frenchPanel.add(french1);
		french1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		frenchPanel.add(french2);
		french2.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		frenchPanel.add(french3);
		french3.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		frenchPanel.add(french4);
		french4.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		frenchPanel.add(french5);
		french5.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		frenchPanel.add(french6);
		french6.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		frenchPanel.add(fAverage);
		fAverage.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		frenchPanel.add(frenchAverage);
		frenchAverage.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		french1.setText("1.0");
		french2.setText("1.0");
		french3.setText("1.0");
		french4.setText("1.0");
		french5.setText("1.0");
		french6.setText("1.0");
		if(Menu.frenchState() == false) {
			frenchPanel.setVisible(false);
		}else {}

		
		JPanel economyPanel = new JPanel();
		economyPanel.setLayout(new GridLayout(1,9));
		economyPanel.add(economy);
		economyPanel.add(economy1);
		economy1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		economyPanel.add(economy2);
		economy2.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		economyPanel.add(economy3);
		economy3.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		economyPanel.add(economy4);
		economy4.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		economyPanel.add(economy5);
		economy5.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		economyPanel.add(economy6);
		economy6.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		economyPanel.add(wrAverage);
		wrAverage.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		economyPanel.add(economyAverage);
		economyAverage.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		economy1.setText("1.0");
		economy2.setText("1.0");
		economy3.setText("1.0");
		economy4.setText("1.0");
		economy5.setText("1.0");
		economy6.setText("1.0");
		if(Menu.economyState() == false) {
			economyPanel.setVisible(false);
		}else {}
		

		JPanel financesPanel = new JPanel();
		financesPanel.setLayout(new GridLayout(1,9));
		financesPanel.add(finances);
		financesPanel.add(finances1);
		finances1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		financesPanel.add(finances2);
		finances2.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		financesPanel.add(finances3);
		finances3.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		financesPanel.add(finances4);
		finances4.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		financesPanel.add(finances5);
		finances5.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		financesPanel.add(finances6);
		finances6.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		financesPanel.add(frwAverage);
		frwAverage.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		financesPanel.add(financesAverage);
		financesAverage.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		finances1.setText("1.0");
		finances2.setText("1.0");
		finances3.setText("1.0");
		finances4.setText("1.0");
		finances5.setText("1.0");
		finances6.setText("1.0");
		if(Menu.financesState() == false) {
			financesPanel.setVisible(false);
		}else {}
		
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new GridLayout(1,5));
		buttonPanel.add(exit);
		buttonPanel.add(reset);
		buttonPanel.add(calc);
		buttonPanel.add(totalLabel);
		buttonPanel.add(total);
		
		
		JPanel GridPanel = new JPanel();
		GridPanel.setLayout(new GridLayout(8,1));
		GridPanel.add(descPanel);
		GridPanel.add(germanPanel);
		GridPanel.add(frenchPanel);
		GridPanel.add(englishPanel);
		GridPanel.add(mathPanel);
		GridPanel.add(economyPanel);
		GridPanel.add(financesPanel);
		GridPanel.add(buttonPanel);
		
		
		getContentPane().add(GridPanel, BorderLayout.CENTER);
		
		
		setSize(750, 200);
		setTitle("Notenrechner");
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Start s = new Start();
				dispose();
			}
		});
		reset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Rechner r = new Rechner();
				dispose();
			}
		});
		calc.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				germanCalculate();
				frenchCalculate();
				englishCalculate();
				mathCalculate();
				economyCalculate();
				financesCalculate();
				calculateTotal();
			}

		});
		
	}
	
	
	public void mathCalculate() {
		float average;
		String averageString;
		average = 	Float.valueOf(math1.getText()) + Float.valueOf(math2.getText()) +
					Float.valueOf(math3.getText()) + Float.valueOf(math4.getText()) +
					Float.valueOf(math5.getText()) + Float.valueOf(math6.getText());
		average = average / 6;
		averageString = Float.toString(average);
			if(average < 4) {
				mathAverage.setBorder(BorderFactory.createLineBorder(Color.RED));
			}else {
				mathAverage.setBorder(BorderFactory.createLineBorder(Color.GREEN));
			}
		mathAverage.setText(averageString);
	}
	
	
	public void germanCalculate() {
		float average;
		String averageString;
		average = 	Float.valueOf(german1.getText()) + Float.valueOf(german4.getText()) +
					Float.valueOf(german2.getText()) + Float.valueOf(german5.getText()) +
					Float.valueOf(german3.getText()) + Float.valueOf(german6.getText());
		average = average / 6;
		averageString = Float.toString(average);
			if(average < 4) {
				germanAverage.setBorder(BorderFactory.createLineBorder(Color.RED));
			}else {
				germanAverage.setBorder(BorderFactory.createLineBorder(Color.GREEN));
			}
		germanAverage.setText(averageString);
	}
	
	
	public void englishCalculate() {
		float average;
		String averageString;
		average = 	Float.valueOf(english1.getText()) + Float.valueOf(english4.getText()) +
					Float.valueOf(english2.getText()) + Float.valueOf(english5.getText()) +
					Float.valueOf(english3.getText()) + Float.valueOf(english6.getText());
		average = average / 6;
		averageString = Float.toString(average);
			if(average < 4) {
				englishAverage.setBorder(BorderFactory.createLineBorder(Color.RED));
			}else {
				englishAverage.setBorder(BorderFactory.createLineBorder(Color.GREEN));
			}
		englishAverage.setText(averageString);
	}

	
	public void frenchCalculate() {
		float average;
		String averageString;
		average = 	Float.valueOf(french1.getText()) + Float.valueOf(french4.getText()) +
					Float.valueOf(french2.getText()) + Float.valueOf(french5.getText()) +
					Float.valueOf(french3.getText()) + Float.valueOf(french6.getText());
		average = average / 6;
		averageString = Float.toString(average);
			if(average < 4) {
				frenchAverage.setBorder(BorderFactory.createLineBorder(Color.RED));
			}else {
				frenchAverage.setBorder(BorderFactory.createLineBorder(Color.GREEN));
			}
		frenchAverage.setText(averageString);
	}
	
	
	public void economyCalculate() {
		float average;
		String averageString;
		average = 	Float.valueOf(economy1.getText()) + Float.valueOf(economy4.getText()) +
					Float.valueOf(economy2.getText()) + Float.valueOf(economy5.getText()) +
					Float.valueOf(economy3.getText()) + Float.valueOf(economy6.getText());
		average = average / 6;
		averageString = Float.toString(average);
			if(average < 4) {
				economyAverage.setBorder(BorderFactory.createLineBorder(Color.RED));
			}else {
				economyAverage.setBorder(BorderFactory.createLineBorder(Color.GREEN));
			}
		economyAverage.setText(averageString);
	}
	
	
	public void financesCalculate() {
		float average;
		String averageString;
		average = 	Float.valueOf(finances1.getText()) + Float.valueOf(finances4.getText()) +
					Float.valueOf(finances2.getText()) + Float.valueOf(finances5.getText()) +
					Float.valueOf(finances3.getText()) + Float.valueOf(finances6.getText());
		average = average / 6;
		averageString = Float.toString(average);
			if(average < 4) {
				financesAverage.setBorder(BorderFactory.createLineBorder(Color.RED));
			}else {
				financesAverage.setBorder(BorderFactory.createLineBorder(Color.GREEN));
			}
		financesAverage.setText(averageString);
	}
	
	
	public void calculateTotal() {
		float average;
		String averageString;
		average = 	Float.valueOf(financesAverage.getText()) + Float.valueOf(economyAverage.getText()) +
					Float.valueOf(mathAverage.getText()) + Float.valueOf(germanAverage.getText()) +
					Float.valueOf(frenchAverage.getText()) + Float.valueOf(englishAverage.getText());
		average = average / 6;
		averageString = Float.toString(average);
			if(average < 4) {
				total.setBorder(BorderFactory.createLineBorder(Color.RED));
			}else {
				total.setBorder(BorderFactory.createLineBorder(Color.GREEN));
			}
		total.setText(averageString);
		
	}
	
}
