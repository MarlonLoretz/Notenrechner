package Main;

import gui.Start;

public class Main {
	
	public static void main(String[] args) {
		
		Start start = new Start();
	}

}
